package character_creation_tests;

import static org.junit.Assert.*;

import org.junit.Test;

import src.Utilities;

public class calculateNPCClassBaseSaveTest 
{

	@Test
	public void calculateNPCClassBaseSaveTest1() 
	{
		// Declare a class key
		int[] test_key = {1,0,1};
		int test_level = 3;
		int[] test_saves = Utilities.calculateNPCClassBaseSave(test_key, test_level);
		// Saves should be [0] = 3, [1] = 1, [2] = 3
		assertEquals(3, test_saves[0]);
		assertEquals(1, test_saves[1]);
		assertEquals(3, test_saves[2]);
	}

}
