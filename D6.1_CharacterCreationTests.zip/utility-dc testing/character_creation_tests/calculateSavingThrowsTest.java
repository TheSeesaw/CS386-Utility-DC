package character_creation_tests;

import static org.junit.Assert.*;
import src.*;

import org.junit.Test;

public class calculateSavingThrowsTest 
{

	@Test
	public void calculateSavingThrowsTest1() 
	{
		// Initialize an NPC
		NonPlayerCharacter t_npc = new NonPlayerCharacter();
		t_npc.setRace("Dwarf");
		t_npc.setJob("Warrior");
		int[] default_attributes = {10,10,10,10,10,10};
		t_npc.setAttributes(default_attributes);
		Utilities.applyRacialBonuses(t_npc);
		Utilities.calculateSavingThrows(t_npc);
		// Fortitude should equal 3
		assertEquals(3, t_npc.getSaves()[0]);
		// Reflect should equal 0
		assertEquals(0, t_npc.getSaves()[1]);
		// Will should equal 1
		assertEquals(1, t_npc.getSaves()[2]);
	}

}
