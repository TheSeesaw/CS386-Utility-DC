package character_creation_tests;

import static org.junit.Assert.*;

import org.junit.Test;

import src.NonPlayerCharacter;
import src.Utilities;

public class getABModifierTest 
{

	@Test
	public void getABModifierTest1() 
	{
		// Initialize a test character
		NonPlayerCharacter t_npc = new NonPlayerCharacter();
		t_npc.setRace("Dwarf");
		t_npc.setJob("Warrior");
		int[] default_attributes = {14,9,15,10,12,10};
		t_npc.setAttributes(default_attributes);
		Utilities.applyRacialBonuses(t_npc);
		// Test the modifier of each attribute
		// Should be: str = 2, dex = -1, con = 3, int = 0, wis = 2, cha = -1
		int str = t_npc.getABModifier("str");
		int dex = t_npc.getABModifier("dex");
		int con = t_npc.getABModifier("con");
		int inte = t_npc.getABModifier("int");
		int wis = t_npc.getABModifier("wis");
		int cha = t_npc.getABModifier("cha");
		assertEquals(2, str);
		assertEquals(-1, dex);
		assertEquals(3, con);
		assertEquals(0, inte);
		assertEquals(2, wis);
		assertEquals(-1, cha);
		
	}

}
