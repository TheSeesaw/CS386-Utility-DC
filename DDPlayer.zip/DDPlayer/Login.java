import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Login
{
  private User[] users;
  private JFrame frame;
  private JPasswordField passwordField;
  private JTextField userNameField;
  private JPanel panel1;
  private JPanel panel2;
  private JLabel passwordLabel;
  private JLabel userNameLabel;
  private JButton submitButton;


  public Login(User[] users)
  {
    this.users = users;
    // initialize the frame
    frame = new JFrame("Log in screen");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(300, 200);

    // create the panels
    // panel1 has text fields
    panel1 = new JPanel();


    // create the submit button
    submitButton = new JButton("Submit");


    // create the username and password fields and labels
    userNameLabel = new JLabel("User Name");
    passwordLabel = new JLabel("Password");
    panel1.setLayout(new BoxLayout(panel1, BoxLayout.PAGE_AXIS));
    userNameField = new JTextField(25);
    passwordField = new JPasswordField(25);

    submitButton.addActionListener(new ButtonListener());

    // add the stuff to the panels
    panel1.add(userNameLabel);
    panel1.add(userNameField);
    panel1.add(passwordLabel);
    panel1.add(passwordField);
    panel1.add(submitButton);
    frame.getContentPane().add(panel1);
		frame.pack();
		frame.setVisible(true);
  }


  class ButtonListener implements ActionListener
  {
    ButtonListener()
      {
      }
    public void actionPerformed(ActionEvent e)
    {
      if (e.getActionCommand().equals("Submit"))
      {
        boolean activated = false;
        for(int i=0;i<users.length;i++)
        {
          if(users[i]!=null)
          {
            if(userNameField.getText().compareTo(users[i].getUserName())==0)
            {
              activated = true;
              if(passwordField.getText().compareTo(users[i].getPassword())==0)
              {
                userNameField.setText("SUCCESS!!!!!!!!!!");
              }
              else
              {
                userNameField.setText("FAILURE!!!!!!!!!!");
              }
            }
          }
        }
        if(activated==false)
        {
          userNameField.setText("Incorrect User Name");
        }
      }
    }
  }



}
