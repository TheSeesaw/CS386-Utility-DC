public class Runner
{
  public static void main(String[] args)
  {
    User a = new User("Barry", "Flash");
    User b = new User("Allen", "Unicorn1");
    User[] users = new User[2];
    users[0] = a;
    users[1] = b;
    Login login = new Login(users);
  }
}
